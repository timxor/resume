# august_2023


august_2023


```

mkdir august_2023/v1

cd august_2023/v1

pdflatex ./../cv_tim_siwula_august_2023.tex .

open cv_tim_siwula_august_2023.pdf


```



